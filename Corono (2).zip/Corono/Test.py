import sys
import webbrowser
import pyperclip
import requests

# webbrowser.open('https://www.google.com/maps/place/Tower16 The close North Apartments')

# res = requests.get('https://automatetheboringstuff.com/files/rj.txt')
# res.raise_for_status()
# playFile = open('Shakespeare.txt', 'wb')
# for chunk in res.iter_content(100000):
#     playFile.write(chunk)
# playFile.close()

import requests, sys, webbrowser, bs4


# print('Googling...')    # display text while downloading the search result page
# res = requests.get('https://google.com/search?q=' + ' '.join(sys.argv[1:]))
#
# res.raise_for_status()
# # Retrieve top search result links.
# soup = bs4.BeautifulSoup(res.text)
# # print(soup)
# # Open a browser tab for each result.
# linkElems = soup.select('.l a')
# print(len(linkElems))
# numOpen = min(5, len(linkElems))
# for i in range(numOpen):
#     webbrowser.open('https://google.com' + linkElems[i].get('href'))

# import os
# url = 'https://xkcd.com'               # starting url
# os.makedirs('xkcd', exist_ok=True)    # store comics in ./xkcd
# while not url.endswith('#'):
#     print('Downloading page %s...' % url)
#     res = requests.get(url)
#     res.raise_for_status()
#
#     soup = bs4.BeautifulSoup(res.text, 'html.parser')
#     comicElem = soup.select('#comic img')
#     if comicElem == []:
#         print('Could not find comic image.')
#     else:
#         comicUrl = 'https:' + comicElem[0].get('src')
#         # Download the image.
#         print('Downloading image %s...' % (comicUrl))
#         res = requests.get(comicUrl)
#         res.raise_for_status()
#         imageFile = open(os.path.join('xkcd', os.path.basename(comicUrl)), 'wb')
#         for chunk in res.iter_content(100000):
#             imageFile.write(chunk)
#         imageFile.close()
#
#         # Get the Prev button's url.
#     prevLink = soup.select('a[rel="prev"]')[0]
#     url = 'https://xkcd.com' + prevLink.get('href')
#
#
#
# print('Done.')

from selenium import webdriver

# browser = webdriver.
type(browser)
browser.get('https://inventwithpython.com')
