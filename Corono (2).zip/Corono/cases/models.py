from django.db import models


class State(models.Model):
    state_or_ut = models.CharField(max_length=255)
    cases = models.IntegerField()
    active = models.IntegerField()
    recovered = models.IntegerField()
    deceased = models.IntegerField()


class Statewise(models.Model):
    state = models.CharField(max_length=255)
    statecode = models.CharField(max_length=50)
    confirmed = models.IntegerField(null=True)
    deltaconfirmed = models.IntegerField(null=True)
    active = models.IntegerField(null=True)
    deaths = models.IntegerField(null=True)
    deltadeaths = models.IntegerField(null=True)
    recovered = models.IntegerField(null=True)
    deltarecovered = models.IntegerField(null=True)
    lastupdatedtime = models.DateTimeField(null=True)


class Prediction(models.Model):
    datastamp = models.DateField()
    confirmed = models.IntegerField(null=True)
    recovered = models.IntegerField(null=True)
    deaths = models.IntegerField(null=True)