import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
# %matplotlib inline
import warnings
from fbprophet import Prophet
from django.shortcuts import render
from plotly.offline import plot
import sqlite3
import plotly.graph_objects as go


def statedata(request):

    # EXTRACTING DATA FROM DATA BASE
    conn = sqlite3.connect('db.sqlite3')
    c = conn.cursor()
    conn1 = sqlite3.connect('db.sqlite3')
    c1 = conn1.cursor()
    conn2 = sqlite3.connect('db.sqlite3')
    c2 = conn2.cursor()
    sql = "SELECT * FROM cases_statewise WHERE state != 'Total'"
    sql1 = 'SELECT * FROM cases_predictions'
    sql2 = "SELECT * FROM cases_statewise WHERE state ='Total'"
    c.execute(sql)
    c1.execute(sql1)
    c2.execute(sql2)
    data = c.fetchall()
    data1 = c1.fetchall()
    data2 = c2.fetchall()
    # print(data)
    c.execute(sql)
    c1.execute(sql1)
    c2.execute(sql2)

    # CREATING LISTS FOR THE INSERTION OF DATA
    states = []
    confirmed = []
    active = []
    recovered = []
    deceased = []
    dates = []
    confirmed_predict = []
    recovered_predict = []
    deaths_predict = []
    total = []
    t_confirmed = []
    t_active = []
    t_recovered = []
    t_deceased = []
    c_list = []
    total_cases = ['Active', 'Recovered', 'Deceased']

    # INSERTING EXTRACTED DATA INTO LISTS
    for row in data:
        states.append(row[8])
        confirmed.append(row[1])
        active.append(row[0])
        recovered.append(row[7])
        deceased.append(row[2])

    for column in data1:
        dates.append(column[0])
        confirmed_predict.append(column[1])
        recovered_predict.append(column[2])
        deaths_predict.append(column[3])

    for row in data2:
        total.append(row[8])
        t_confirmed.append(row[1])
        t_active.append(row[0])
        t_recovered.append(row[7])
        t_deceased.append(row[2])

    c_total = 0
    for c_num in confirmed:
        c_total += int(c_num)
    c_list.append(c_total)

    r_total = 0
    for r_num in recovered:
        r_total += int(r_num)
    c_list.append(r_total)

    d_total = 0
    for d_num in deceased:
        d_total += int(d_num)
    c_list.append(d_total)

    # PLOTTING BAR & PIE CHARTS ALONG WITH TABLES
    total_table = go.Figure(data=[
        go.Table(header=dict(values=['Total Cases', 'Confirmed', 'Active', 'Recovered', 'Deceased']),
                 cells=dict(values=[total, t_confirmed, t_active, t_recovered, t_deceased], align='left'))])
    table = go.Figure(data=[
        go.Table(columnwidth=[15, 10, 10, 10, 10],
                 header=dict(values=['State/UT', 'Confirmed', 'Active', 'Recovered', 'Deceased']),
                 cells=dict(values=[states, confirmed, active, recovered, deceased], align='left'))])
    predict_table = go.Figure(data=[
        go.Table(columnwidth=[15, 10, 10, 10],
                 header=dict(values=['Date', 'Confirmed', 'Recovered', 'Deceased']),
                 cells=dict(values=[dates, confirmed_predict, recovered_predict, deaths_predict], align='right'))])

    bar = go.Figure(data=[
        go.Bar(name='Total Cases', x=states, y=confirmed),
        go.Bar(name='Active Cases', x=states, y=active),
        go.Bar(name='Recovered Cases', x=states, y=recovered),
        go.Bar(name='Deceased Cases', x=states, y=deceased)])
    predict_bar = go.Figure(data=[
        go.Bar(name='Confirmed', x=dates, y=confirmed_predict),
        go.Bar(name='Recovered', x=dates, y=recovered_predict),
        go.Bar(name='Deaths', x=dates, y=deaths_predict)])

    state_pie = go.Figure(data=[
        go.Pie(labels=states, values=confirmed, title='Pie Chart  of Cases State-wise')])
    case_pie = go.Figure(data=[
        go.Pie(labels=total_cases, values=c_list, title='Pie Chart  of Total Cases in India')])

    bar.update_layout(title_text="State-wise Corona Cases", barmode='group')
    case_pie.update_traces(marker=dict(line=dict(color='#000000', width=2)))
    table.update_layout(width=650, height=750)
    total_table.update_layout(width=650, height=275)
    predict_table.update_layout(width=650, height=750)
    predict_bar.update_layout(title_text="Predicition Of Corona Cases in India", barmode='group')

    # PLOTTING THE GRAPHS AND TABLES
    table_plot = plot(table, output_type='div')
    total_table_plot = plot(total_table, output_type='div')
    bar_plot = plot(bar, output_type='div')
    state_pie_plot = plot(state_pie, output_type='div')
    case_pie_plot = plot(case_pie, output_type='div')
    predict_table_plot = plot(predict_table, output_type='div')
    predict_bar_plot = plot(predict_bar, output_type='div')

    # RENDERING CHART AND TABLE TO INSERT.HTML
    return render(request, 'index.html', {'table_plot': table_plot, 'bar_plot': bar_plot, 'state_pie_plot': state_pie_plot, 'case_pie_plot': case_pie_plot, 'predict_table_plot': predict_table_plot, 'predict_bar_plot': predict_bar_plot, 'total_table_plot': total_table_plot})


def predictdata(request):
    conn = sqlite3.connect('db.sqlite3')
    c = conn.cursor()
    sql1 = 'select * from cases_predictions'
    c.execute(sql1)
    data1 = c.fetchall()
    c.execute(sql1)

    dates = []
    confirmed_predict = []
    recovered_predict = []
    deaths_predict = []
    for column in c.fetchall():
        dates.append(column[0])
        confirmed_predict.append(column[1])
        recovered_predict.append(column[2])
        deaths_predict.append(column[3])

    predict_table = go.Figure(data=[
        go.Table(columnwidth=[10, 10, 10, 10, 10],
                 header=dict(values=['Date', 'Confirmed', 'Recovered', 'Deceased']),
                 cells=dict(values=[dates, confirmed_predict, recovered_predict, deaths_predict], align='right'))])

    predict_bar = go.Figure(data=[
        go.Bar(name='Confirmed', x=dates, y=confirmed_predict),
        go.Bar(name='Recovered', x=dates, y=recovered_predict),
        go.Bar(name='Deaths', x=dates, y=deaths_predict)])

    predict_table.update_layout(width=600, height=875)
    predict_bar.update_layout(title_text="Visual Representation of Predicition", barmode='group')

    predict_table_plot = plot(predict_table, output_type='div')
    predict_bar_plot = plot(predict_bar, output_type='div')

    return render(request, 'index.html', {'predict_table_plot': predict_table_plot, 'predict_bar_plot': predict_bar_plot})

# conn = sqlite3.connect('db.sqlite3')
# c = conn.cursor()
# conn1 = sqlite3.connect('db.sqlite3')
# c1 = conn1.cursor()
# sql = "select * from cases_statewise"
# sql1 = 'select * from cases_predictions'
# c.execute(sql)
# c1.execute(sql1)
# data = c.fetchall()
# data1 = c1.fetchall()
# print(data)