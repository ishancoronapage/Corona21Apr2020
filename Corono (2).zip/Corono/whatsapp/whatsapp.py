from twilio.rest import Client

account_sid = 'AC4fc744f94a7fa5ef31be2afa40f060a8'
auth_token = '1204bfa73784a39f489d5165ce778f02'
client = Client(account_sid, auth_token)


def send_message():
    message = client.messages.create(
        from_='whatsapp:+14155238886',
        body='Hello',
        to='whatsapp:+919818435074')
    print(message.sid)