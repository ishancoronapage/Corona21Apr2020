import requests
import pandas as pd
import json
import sqlite3
from Prediction import final

# READING FROM STATE JSON FILE
india_data1 = requests.get('https://api.covid19india.org/data.json')
json_file1 = india_data1.json()
# print(json_file1)
india1 = pd.read_json(json.dumps(json_file1['statewise']))
# print(india1)

# INSERTING STATE JSON INTO DB
conn = sqlite3.connect('db.sqlite3')
c = conn.cursor()
india1.to_sql('cases_statewise', conn, if_exists='replace', index=False)
conn.commit()
c.close()


# READING FROM INDIA JSON FILE
data_extract = requests.get('https://pomber.github.io/covid19/timeseries.json')
json_file2 = data_extract.json()
read = pd.read_json(json.dumps(json_file2['India']))
# print(read)

# INSERTING INDIA DATA INTO DB
conn1 = sqlite3.connect('db.sqlite3')
c1 = conn1.cursor()
read.to_sql('cases_india', conn1, if_exists='replace', index=False)
conn1.commit()
c1.close()

# INSERTING PREDICTED INDIA DATA INTO DB
connect = sqlite3.connect('db.sqlite3')
cursor = connect.cursor()
final.to_sql('cases_predictions', connect, if_exists='replace', index=True, index_label='datastamp')
connect.commit()
cursor.close()