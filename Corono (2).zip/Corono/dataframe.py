import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
# %matplotlib inline
import warnings
from fbprophet import Prophet


warnings.filterwarnings('ignore')
india_data = requests.get('https://pomber.github.io/covid19/timeseries.json')
json_file = india_data.json()
india = pd.read_json(json.dumps(json_file['India']))
print(india)

con = india[['date', 'confirmed']]
con.columns = ['ds', 'y']
con['ds'] = pd.to_datetime(con['ds'])
# con.tail(10)
# print(con.tail(10))
con = con.set_index(con['ds'])
del con['ds']
# con.tail(5)
# print(con.tail(5))
con_diff = con.diff(periods=1)
con_diff['ds'] = con_diff.index
con_train_last = con.loc['2020-04-06'].copy()
split_date = '2020-04-06'
train = con_diff.loc[(con_diff['ds'] > '2020-04-01') & (con_diff['ds'] <= split_date)].copy()
test = con_diff.loc[con_diff.index > split_date].copy()
model = Prophet(interval_width=0.95)
model.fit(train)
diff_prediction = model.predict(test)
diff_prediction[['yhat', 'ds']].round()
# print(con_train_last)
cum_prediction = diff_prediction
# print(cum_prediction['yhat'][0])
cum_prediction['yhat'][0] = cum_prediction['yhat'][0] + con_train_last
# print(cum_prediction['yhat'][0].round())
cum_prediction['yhat'] = cum_prediction['yhat'].cumsum()
# print(cum_prediction['yhat'].round())
cum_prediction['yhat'] = cum_prediction['yhat'].round()
# print(con['y'].tail(8))
cum_prediction = cum_prediction.set_index(cum_prediction['ds'])
compare = pd.concat([con, cum_prediction], axis=1, join='inner')
# print(compare[['y', 'yhat']])
for row in compare:
    compare['percentage'] = ((compare['y']-compare['yhat'])/compare['y'])*100
    compare['percentage'].append
# print(compare[['y', 'yhat', 'percentage']])

#  Future Prediction

train1 = con_diff.loc[(con_diff['ds'] > '2020-03-24') & (con_diff['ds'] <= '2020-04-07')].copy()
# test1 = con_diff.loc[con_diff.index > split_date].copy()
model1 = Prophet(interval_width=0.95)
model1.fit(train)

future = model1.make_future_dataframe(periods=24)
con_future=model1.predict(future)
con_future_ds=con_future[['ds', 'yhat']]
# print(con_future_ds.round())
cum_predict2 = con_future
# print(cum_predict2['yhat'][0])
con_train_last = con.loc['2020-04-01'].copy()
cum_predict2['yhat'][0] = cum_predict2['yhat'][0] + con_train_last
# print(cum_predict2['yhat'][0].round())
cum_predict2['yhat'] = cum_predict2['yhat'].cumsum()
cum_predict2['yhat'].round()
# print(cum_predict2[['ds', 'yhat']].round())
cum_predict2 = cum_predict2.set_index(cum_predict2['ds'])
compare2 = pd.concat([con, cum_predict2], axis=1, join='inner')
for row in compare2:
    compare2['percentage'] = ((compare2['y']-compare2['yhat'])/compare2['y'])*100
    compare2['percentage'].append
# print(compare2[['y', 'yhat', 'percentage']].round(2))
# x = cum_predict2['yhat']
# y = cum_predict2['ds']
# plt.plot(x, y)
# plt.show()